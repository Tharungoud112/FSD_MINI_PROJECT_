/* StreakSmith – data layer: LocalStorage persistence, streak engine,
   5-tier heatmap levels, freeze pass, badges and accountability-buddy logic. */
const Store = (() => {
  'use strict';
  const KEY = 'streaksmith.v1';
  const CATS = { Health: '#ef4444', Coding: '#3b82f6', Learning: '#f59e0b', Mindfulness: '#a855f7' };
  const FREQ = { everyday: 'Everyday', weekdays: 'Weekdays', '3x': '3x / week' };
  const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const MILESTONES = [7, 30, 100, 365];

  /* ---------- date helpers: every date is a YYYY-MM-DD string; math is done in UTC
     so month lengths, leap years and DST can never break streak continuity ---------- */
  const pad = n => String(n).padStart(2, '0');
  const fmt = d => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  const parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)); };
  const today = () => { const n = new Date(); return `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`; };
  const addDays = (s, n) => { const d = parse(s); d.setUTCDate(d.getUTCDate() + n); return fmt(d); };
  const dow = s => parse(s).getUTCDay();                       // 0 = Sunday
  const weekStart = s => addDays(s, -((dow(s) + 6) % 7));      // Monday
  const range = (a, b) => { const o = []; for (let d = a; d <= b; d = addDays(d, 1)) o.push(d); return o; };
  const isDue = (freq, d) => freq === 'weekdays' ? (dow(d) >= 1 && dow(d) <= 5) : true;

  const rng = seed => () => {            // mulberry32 – deterministic sample data
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
  const hash = s => [...s].reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 7);

  /* ---------- sample data: 6 habits, 90 days of history, linked buddy ---------- */
  const SEED = [
    ['LeetCode Daily Challenge', 'Coding', 'everyday', '09:00', 0.8],
    ['30-Minute Gym Workout', 'Health', 'weekdays', '18:00', 0.7],
    ['Read 15 Pages', 'Learning', 'everyday', '21:00', 0.65],
    ['Drink 3L Water', 'Health', 'everyday', '20:00', 0.75],
    ['10-Min Meditation', 'Mindfulness', 'everyday', '07:00', 0.6],
    ['Write Daily Journal', 'Learning', '3x', '22:00', 0.5]
  ];
  function buddyToday(name, t) {
    const r = rng(hash(name + t)), o = {};
    SEED.slice(1, 5).forEach(s => { if (r() < 0.5) o[s[0]] = true; });   // LeetCode stays pending
    return o;
  }
  function makeBuddy(name) {
    const t = today(), r = rng(hash(name) + 7), logs = {};
    for (let k = 1; k <= 90; k++) {
      const d = addDays(t, -k); logs[d] = {};
      SEED.slice(0, 5).forEach(s => { if (isDue(s[2], d) && r() < 0.72) logs[d][s[0]] = true; });
    }
    logs[t] = buddyToday(name, t);
    return { name, habits: SEED.slice(0, 5).map(s => ({ name: s[0], cat: s[1], freq: s[2] })),
             logs, verified: {}, nudges: [], fives: [] };
  }
  function seedState() {
    const t = today(), r = rng(42), habits = [], logs = {};
    SEED.forEach((s, i) => habits.push({ id: 'h' + (i + 1), name: s[0], cat: s[1], freq: s[2], remind: s[3], created: addDays(t, -90) }));
    for (let k = 1; k <= 90; k++) {
      const d = addDays(t, -k); logs[d] = {};
      habits.forEach((h, i) => {
        const on = i === 0 ? (k <= 14 ? true : k === 15 ? false : r() < 0.8)   // LeetCode: exactly a 14-day streak
                           : (isDue(h.freq, d) && r() < SEED[i][4]);
        if (on) logs[d][h.id] = `${d}T${pad(6 + Math.floor(r() * 16))}:${pad(Math.floor(r() * 60))}:00`;
      });
    }
    return { habits, logs, freezes: {}, buddy: makeBuddy('Devon') };
  }

  /* ---------- state + persistence ---------- */
  let state = null; const subs = [];
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* storage full / disabled */ } };
  const commit = () => { subs.forEach(f => f()); save(); };   // optimistic: UI updates in memory first, then persist
  function ensureBuddy() {
    const t = today(), b = state.buddy;
    if (b && b.habits.length && !b.logs[t]) b.logs[t] = buddyToday(b.name, t);
  }
  function init() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) { const s = JSON.parse(raw); if (s && Array.isArray(s.habits) && s.logs && s.buddy) state = s; }
    } catch (e) { state = null; }
    if (!state) state = seedState();
    if (!state.freezes) state.freezes = {};
    ensureBuddy(); save();
  }
  const on = f => subs.push(f);

  const habits = () => state.habits;
  const isDone = (id, d = today()) => !!(state.logs[d] && state.logs[d][id]);
  const doneAt = (id, d = today()) => (state.logs[d] || {})[id];
  const isFrozen = (d = today()) => !!state.freezes[d];

  function earliest() {
    let m = today();
    state.habits.forEach(h => { if (h.created < m) m = h.created; });
    Object.keys(state.logs).forEach(d => { if (d < m) m = d; });
    return m;
  }

  /* ---------- streak engine ---------- */
  // Walk backwards day-by-day. A pending "today" never breaks a streak (it is only "At Risk").
  // Unscheduled days (e.g. weekends for a Weekdays habit) are skipped; frozen days bridge gaps.
  function dailyCurrent(done, sched, t) {
    let d = t, n = 0;
    if (!done(d) && !isFrozen(d)) d = addDays(d, -1);
    for (let i = 0; i < 4000; i++) {
      if (sched(d)) { if (done(d)) n++; else if (!isFrozen(d)) break; }
      d = addDays(d, -1);
    }
    return n;
  }
  function longestDaily(done, sched, from, to) {
    let cur = 0, best = 0;
    for (const d of range(from, to)) {
      if (!sched(d)) continue;
      if (done(d)) { cur++; if (cur > best) best = cur; }
      else if (d !== to && !isFrozen(d)) cur = 0;
    }
    return best;
  }
  function habitStats(h) {
    const t = today(), f = d => isDone(h.id, d), from = earliest();
    let current, longest = 0, unit = 'day', atRisk = false;
    if (h.freq === '3x') {                       // streak counted in weeks that reach the 3-check-in target
      unit = 'week';
      const cnt = ws => range(ws, addDays(ws, 6)).filter(f).length, cw = weekStart(t);
      current = 0; let ws = cw;
      if (cnt(ws) >= 3) current++;
      ws = addDays(ws, -7);
      while (cnt(ws) >= 3 && current < 600) { current++; ws = addDays(ws, -7); }
      let run = 0;
      for (let w = weekStart(from); w <= cw; w = addDays(w, 7)) {
        if (cnt(w) >= 3) { run++; longest = Math.max(longest, run); } else if (w !== cw) run = 0;
      }
      const left = 7 - ((dow(t) + 6) % 7), have = cnt(cw);
      atRisk = current > 0 && have < 3 && !f(t) && !isFrozen(t) && left <= 3 - have;
    } else {
      const sched = d => isDue(h.freq, d);
      current = dailyCurrent(f, sched, t);
      longest = longestDaily(f, sched, from, t);
      atRisk = sched(t) && !f(t) && !isFrozen(t) && current > 0;
    }
    return { current, longest: Math.max(longest, current), unit, atRisk };
  }
  function overall() {
    const t = today(), any = d => state.habits.some(h => isDone(h.id, d)), all = () => true;
    const current = dailyCurrent(any, all, t);
    return { current, longest: Math.max(current, longestDaily(any, all, earliest(), t)),
             atRisk: current > 0 && !any(t) && !isFrozen(t) };
  }

  /* ---------- heatmap: Level 0-4 ---------- */
  function dayInfo(d, fid) {
    const L = state.logs[d] || {};
    if (fid) { const done = L[fid] ? 1 : 0; return { done, due: 1, level: done ? 4 : 0 }; }
    const hs = state.habits.filter(h => h.created <= d || L[h.id]);
    const done = hs.filter(h => L[h.id]).length;
    const due = Math.max(1, hs.filter(h => isDue(h.freq, d)).length);
    const ratio = Math.min(1, done / due);
    return { done, due, level: done === 0 ? 0 : ratio <= 0.25 ? 1 : ratio <= 0.5 ? 2 : ratio <= 0.75 ? 3 : 4 };
  }
  function monthly(n = 6) {
    const t = today(), out = [], e = earliest();
    let y = +t.slice(0, 4), m = +t.slice(5, 7);
    for (let i = 0; i < n; i++) {
      const key = `${y}-${pad(m)}`, last = key === t.slice(0, 7) ? t : fmt(new Date(Date.UTC(y, m, 0)));
      let done = 0, due = 0;
      for (let d = `${key}-01`; d <= last; d = addDays(d, 1)) { if (d < e) continue; const di = dayInfo(d); done += di.done; due += di.due; }
      out.unshift({ key, label: MONTHS[m - 1], done, pct: due ? Math.round(Math.min(1, done / due) * 100) : 0 });
      if (--m === 0) { m = 12; y--; }
    }
    return out;
  }
  function badges() {
    const best = overall().longest;
    return MILESTONES.map(days => ({ days, best, earned: best >= days }));
  }

  /* ---------- habit CRUD + check-in ---------- */
  function toggle(id, d = today()) {
    if (!state.habits.some(h => h.id === id)) return;
    state.logs[d] = state.logs[d] || {};
    if (state.logs[d][id]) delete state.logs[d][id]; else state.logs[d][id] = new Date().toISOString();
    commit();
  }
  const clean = o => ({
    name: String(o.name || '').trim().slice(0, 40),
    cat: CATS[o.cat] ? o.cat : 'Health',
    freq: FREQ[o.freq] ? o.freq : 'everyday',
    remind: /^\d\d:\d\d$/.test(o.remind) ? o.remind : '09:00'
  });
  function addHabit(o) {
    const c = clean(o); if (!c.name) return null;
    const h = { id: 'h' + Date.now().toString(36) + Math.floor(Math.random() * 99), ...c, created: today() };
    state.habits.push(h); commit(); return h;
  }
  function updateHabit(id, o) {
    const h = state.habits.find(x => x.id === id); if (!h) return;
    const c = clean({ ...h, ...o }); if (!c.name) return;
    Object.assign(h, c); commit();
  }
  function removeHabit(id) {
    state.habits = state.habits.filter(h => h.id !== id);
    Object.values(state.logs).forEach(L => delete L[id]);
    commit();
  }

  /* ---------- streak freeze: one token per calendar month ---------- */
  const freezeAvailable = () => !Object.keys(state.freezes).some(d => d.slice(0, 7) === today().slice(0, 7));
  function useFreeze() { if (!freezeAvailable()) return false; state.freezes[today()] = true; commit(); return true; }

  /* ---------- accountability buddy ---------- */
  function buddyView() {
    const t = today(), b = state.buddy;
    const items = b.habits.map(h => {
      const f = d => !!(b.logs[d] && b.logs[d][h.name]);
      return { name: h.name, cat: h.cat, freq: h.freq, done: f(t), due: isDue(h.freq, t),
        streak: dailyCurrent(f, d => isDue(h.freq, d), t),
        verified: !!b.verified[t + '|' + h.name],
        nudged: b.nudges.some(n => n.date === t && n.habit === h.name),
        fived: b.fives.some(n => n.date === t && n.habit === h.name) };
    });
    const any = d => b.habits.some(h => b.logs[d] && b.logs[d][h.name]);
    const feed = [...b.nudges.map(n => ({ ...n, type: 'nudge' })), ...b.fives.map(n => ({ ...n, type: 'five' }))]
      .sort((x, y) => y.ts - x.ts).slice(0, 6);
    return { name: b.name, items, streak: dailyCurrent(any, () => true, t), feed };
  }
  const react = (list, habit) => { list.push({ date: today(), habit, ts: Date.now() }); commit(); };
  const nudge = h => react(state.buddy.nudges, h);
  const highFive = h => react(state.buddy.fives, h);
  function verify(h) { state.buddy.verified[today() + '|' + h] = true; commit(); }
  function setBuddy(name) { state.buddy = makeBuddy(name); commit(); }

  function reset() { state = seedState(); commit(); }
  function clearAll() { state = { habits: [], logs: {}, freezes: {}, buddy: state.buddy }; commit(); }

  return { CATS, FREQ, MONTHS, today, addDays, weekStart, isDue, on, init, rollover: ensureBuddy,
    habits, isDone, isFrozen, doneAt, toggle, addHabit, updateHabit, removeHabit,
    habitStats, overall, dayInfo, monthly, badges, freezeAvailable, useFreeze,
    buddyView, nudge, highFive, verify, setBuddy, reset, clearAll };
})();
if (typeof module !== 'undefined') module.exports = Store;
