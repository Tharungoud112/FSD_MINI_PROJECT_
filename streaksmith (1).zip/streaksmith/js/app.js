/* StreakSmith – UI layer: hash router, views, heatmap renderer, modal, reminders */
(() => {
  'use strict';
  const S = Store;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const timeStr = ts => ts ? new Date(ts).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '';
  const mq = matchMedia('(max-width: 639px)');
  const dlg = $('#habitDialog'), form = $('#habitForm');
  let view = 'dashboard', heatFilter = 'all', editingId = null, bump = false, pulseId = null;

  function toast(msg) {
    const t = $('#toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toast.id); toast.id = setTimeout(() => t.classList.remove('show'), 2800);
  }

  /* ---------- shared snippets ---------- */
  const stat = (ico, label, val, sub, cls = '') =>
    `<div class="stat"><span class="ico">${ico}</span><div><small>${label}</small><b class="${cls}">${val}</b><em>${sub}</em></div></div>`;
  const filterSelect = () => `<label class="sel no-print"><span class="sr">Habit filter</span><select data-filter>
    <option value="all" ${heatFilter === 'all' ? 'selected' : ''}>All habits</option>
    ${S.habits().map(h => `<option value="${h.id}" ${heatFilter === h.id ? 'selected' : ''}>${esc(h.name)}</option>`).join('')}</select></label>`;
  const legend = () => `<div class="legend"><span>Less</span>${[0, 1, 2, 3, 4].map(l => `<i class="sw lv${l}"></i>`).join('')}<span>More</span>
    <span class="hint">${mq.matches ? 'Last 30 days' : 'Last 52 weeks'}</span></div>`;

  /* ---------- GitHub-style heatmap (SVG). 30-day grid on phones, 52 weeks on desktop ---------- */
  function drawHeat(el) {
    if (!el) return;
    const mobile = mq.matches, t = S.today(), fid = heatFilter === 'all' ? null : heatFilter;
    const start = mobile ? S.addDays(t, -29) : S.addDays(S.weekStart(t), -51 * 7);
    const gs = S.weekStart(start), cell = mobile ? 30 : 12, gap = mobile ? 5 : 3, step = cell + gap, left = mobile ? 0 : 30, top = 20;
    let rects = '', labels = '', lastM = -1, i = 0, cols = 1;
    if (!mobile) [0, 2, 4].forEach(r => { labels += `<text x="0" y="${top + r * step + 10}">${['Mon', 'Tue', 'Wed', 'Thu', 'Fri'][r]}</text>`; });
    for (let d = gs; d <= t; d = S.addDays(d, 1), i++) {
      const col = Math.floor(i / 7), row = i % 7; cols = col + 1;
      if (d < start) continue;
      const info = S.dayInfo(d, fid), x = left + col * step, y = top + row * step;
      if (row === 0) { const m = +d.slice(5, 7) - 1; if (m !== lastM) { labels += `<text x="${x}" y="12">${S.MONTHS[m]}</text>`; lastM = m; } }
      const txt = fid ? (info.done ? 'completed' : 'not completed') : `${info.done} of ${info.due} habits`;
      rects += `<rect class="lv${info.level}${d === t ? ' today' : ''}" x="${x}" y="${y}" width="${cell}" height="${cell}" rx="3"><title>${d}: ${txt} (Level ${info.level})</title></rect>`;
    }
    const W = left + cols * step - gap, H = top + 7 * step - gap;
    el.innerHTML = `<svg class="heat" viewBox="0 0 ${W} ${H}" font-size="${mobile ? 11 : 10}" style="max-width:${Math.round(W * (mobile ? 1.5 : 1.6))}px" role="img" aria-label="Habit activity heatmap">${labels}${rects}</svg>`;
  }

  /* ---------- views ---------- */
  function riskBanner() {
    const at = S.habits().filter(h => S.habitStats(h).atRisk);
    if (!at.length && !S.overall().atRisk) return '';
    const n = new Date(), left = 1440 - (n.getHours() * 60 + n.getMinutes());
    return `<div class="alert ${left <= 240 ? 'urgent' : ''}" role="alert"><span>⚠️</span><div><b>Streak At Risk</b> – ${at.length ? esc(at.slice(0, 3).map(h => h.name).join(', ')) + (at.length > 3 ? '…' : '') + ' still pending.' : 'No check-in yet today.'}
      <em>${Math.floor(left / 60)}h ${left % 60}m until midnight.</em></div>${S.freezeAvailable() && !S.isFrozen() ? '<button class="btn sm" data-action="freeze">❄️ Use freeze</button>' : ''}</div>`;
  }
  function card(h) {
    const s = S.habitStats(h), t = S.today(), done = S.isDone(h.id), due = S.isDue(h.freq, t);
    return `<article class="card ${done ? 'done' : ''} ${pulseId === h.id ? 'pulse' : ''}" style="--cat:${S.CATS[h.cat]}">
      <button class="check" data-action="toggle" data-id="${h.id}" aria-pressed="${done}" aria-label="${done ? 'Undo' : 'Check in'}: ${esc(h.name)}">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg></button>
      <div class="info"><h3>${esc(h.name)}</h3>
        <div class="meta"><span class="tag">${h.cat}</span><span>${S.FREQ[h.freq]}</span><span>⏰ ${h.remind}</span></div>
        <div class="sub">${done ? '✔ Completed at ' + timeStr(S.doneAt(h.id)) : due ? 'Pending today' : 'Rest day (optional)'}</div></div>
      <div class="streak ${s.atRisk ? 'risk' : ''}"><b class="${bump && pulseId === h.id ? 'bump' : ''}">${s.current}</b><small>${s.unit} streak</small>${s.atRisk ? '<span class="badge-risk">At Risk</span>' : ''}</div>
      <div class="actions"><span>Best: ${s.longest} ${s.unit}${s.longest === 1 ? '' : 's'}</span>
        <button class="icon" data-action="edit" data-id="${h.id}" aria-label="Edit ${esc(h.name)}">✎</button>
        <button class="icon" data-action="del" data-id="${h.id}" aria-label="Delete ${esc(h.name)}">🗑</button></div></article>`;
  }
  function renderDashboard() {
    const o = S.overall(), hs = S.habits(), t = S.today(), due = hs.filter(h => S.isDue(h.freq, t));
    const doneN = due.filter(h => S.isDone(h.id)).length, fa = S.freezeAvailable();
    $('#view').innerHTML = `${riskBanner()}
      <section class="stats">
        ${stat('🔥', 'Current streak', o.current, 'days in a row', bump ? 'bump' : '')}
        ${stat('🏆', 'Longest streak', o.longest, 'all-time days')}
        ${stat('✅', 'Today', `${doneN}/${due.length}`, 'scheduled habits')}
        ${stat('❄️', 'Streak freeze', S.isFrozen() ? 'Active' : fa ? '1 left' : 'Used', 'resets monthly')}
      </section>
      <div class="section-head"><h2>Today's habits</h2><button class="btn primary" data-action="add">+ Add habit</button></div>
      <section class="habit-grid">${hs.map(card).join('') || '<p class="empty">No habits yet – add your first one!</p>'}</section>
      <section class="panel"><div class="section-head"><h2>Consistency heatmap</h2>${filterSelect()}</div><div id="heat"></div>${legend()}</section>`;
    drawHeat($('#heat'));
  }
  function renderAnalytics() {
    const hs = S.habits(), o = S.overall(), mo = S.monthly(6), bd = S.badges(), t = S.today();
    const rows = hs.map(h => {
      const s = S.habitStats(h); let c = 0;
      for (let i = 0; i < 30; i++) if (S.isDone(h.id, S.addDays(t, -i))) c++;
      return `<tr><td>${esc(h.name)}</td><td><span class="tag" style="--cat:${S.CATS[h.cat]}">${h.cat}</span></td><td>${S.FREQ[h.freq]}</td><td>${s.current} ${s.unit}s</td><td>${s.longest} ${s.unit}s</td><td>${c}/30</td></tr>`;
    }).join('');
    const icons = { 7: '🥉', 30: '🥈', 100: '🥇', 365: '💎' };
    $('#view').innerHTML = `
      <div class="print-only"><h1>StreakSmith – Habit Performance Report</h1><p>Generated ${new Date().toLocaleDateString(undefined, { dateStyle: 'long' })}</p></div>
      <div class="section-head"><h2>Analytics</h2><button class="btn primary no-print" data-action="print">⬇ Export PDF report</button></div>
      <section class="stats">
        ${stat('🔥', 'Current streak', o.current, 'days')}${stat('🏆', 'Longest streak', o.longest, 'days')}
        ${stat('📅', 'Habits tracked', hs.length, 'active')}${stat('🎯', 'This month', mo[mo.length - 1].pct + '%', 'completion')}
      </section>
      <section class="panel"><div class="section-head"><h2>Activity heatmap</h2>${filterSelect()}</div><div id="heat"></div>${legend()}</section>
      <section class="panel"><h2>Monthly completion rate</h2><div class="bars">${mo.map(m =>
        `<div class="bar"><b>${m.pct}%</b><span style="--p:${m.pct}"></span><small>${m.label}</small></div>`).join('')}</div></section>
      <section class="panel"><h2>Habit performance</h2><div class="table-wrap"><table><thead><tr><th>Habit</th><th>Category</th><th>Frequency</th><th>Current</th><th>Longest</th><th>Last 30 days</th></tr></thead><tbody>${rows}</tbody></table></div></section>
      <section class="panel"><h2>Milestone badges</h2><div class="badges">${bd.map(b =>
        `<div class="badge ${b.earned ? 'on' : ''}"><span>${icons[b.days]}</span><b>${b.days}-day</b><small>${b.earned ? 'Unlocked!' : Math.min(b.best, b.days) + '/' + b.days + ' days'}</small></div>`).join('')}</div></section>`;
    drawHeat($('#heat'));
  }
  function renderBuddy() {
    const v = S.buddyView();
    const mine = S.habits().map(h => `<li class="${S.isDone(h.id) ? 'ok' : ''}"><span>${S.isDone(h.id) ? '✔' : '○'}</span>${esc(h.name)}</li>`).join('') || '<li>No habits yet</li>';
    const feed = v.feed.length ? v.feed.map(f => `<li>${f.type === 'five' ? '🙌 High-fived' : '👋 Nudged'} ${esc(v.name)} on <b>${esc(f.habit)}</b> <small>${timeStr(f.ts)}</small></li>`).join('') : '<li class="muted">No reactions yet today.</li>';
    const rows = v.items.map(i => `<li class="brow ${i.done ? 'ok' : ''}"><div><b>${esc(i.name)}</b>
      <div class="meta"><span class="tag" style="--cat:${S.CATS[i.cat]}">${i.cat}</span><span>🔥 ${i.streak}-day streak</span></div></div>
      <div class="btns">${i.done
        ? `<span class="chip ok">Done</span><button class="btn sm" data-action="verify" data-habit="${esc(i.name)}" ${i.verified ? 'disabled' : ''}>${i.verified ? 'Verified ✔' : 'Verify'}</button>
           <button class="btn sm" data-action="five" data-habit="${esc(i.name)}" ${i.fived ? 'disabled' : ''}>${i.fived ? 'Sent 🙌' : '🙌 High-five'}</button>`
        : i.due ? `<span class="chip warn">Pending</span><button class="btn sm primary" data-action="nudge" data-habit="${esc(i.name)}" ${i.nudged ? 'disabled' : ''}>${i.nudged ? 'Nudged ✓' : 'Send Nudge'}</button>`
                : '<span class="chip">Rest day</span>'}</div></li>`).join('');
    $('#view').innerHTML = `<div class="section-head"><h2>Buddy Hub</h2></div>
      <section class="panel buddy-head"><div class="avatar">${esc(v.name[0].toUpperCase())}</div>
        <div><h3>${esc(v.name)}</h3><p>Accountability partner · 🔥 ${v.streak}-day streak</p></div>
        <form id="buddyForm" class="inline"><label class="sr" for="bn">Buddy name</label><input id="bn" name="buddy" maxlength="24" placeholder="Link a new buddy…" required><button class="btn">Link</button></form></section>
      <section class="panel"><h2>${esc(v.name)}'s habits today</h2><ul class="blist">${rows}</ul></section>
      <div class="two"><section class="panel"><h2>What ${esc(v.name)} sees of you</h2><ul class="mine">${mine}</ul></section>
      <section class="panel"><h2>Recent reactions</h2><ul class="feed">${feed}</ul></section></div>`;
  }
  function renderSettings() {
    const fa = S.freezeAvailable(), np = 'Notification' in window ? Notification.permission : 'unsupported';
    $('#view').innerHTML = `<div class="section-head"><h2>Settings</h2></div>
      <section class="panel set"><div><h3>❄️ Streak Freeze</h3><p>One emergency pass per month protects today's streak during sickness or travel. ${S.isFrozen() ? 'Active for today.' : fa ? 'Available this month.' : 'Already used this month.'}</p></div>
        <button class="btn" data-action="freeze" ${fa && !S.isFrozen() ? '' : 'disabled'}>Use freeze</button></section>
      <section class="panel set"><div><h3>⏰ Reminders</h3><p>Habit reminders appear in-app at each habit's reminder time. Browser notifications: <b>${np}</b>.</p></div>
        <button class="btn" data-action="notify" ${np === 'default' ? '' : 'disabled'}>Enable notifications</button></section>
      <section class="panel set"><div><h3>🗂 Data</h3><p>Everything is saved in your browser's LocalStorage.</p></div>
        <div class="btns"><button class="btn" data-action="reset">Reload demo data</button><button class="btn danger" data-action="clear">Clear all habits</button></div></section>`;
  }

  /* ---------- router + render ---------- */
  const routes = { dashboard: renderDashboard, analytics: renderAnalytics, buddy: renderBuddy, settings: renderSettings };
  function render() {
    if (heatFilter !== 'all' && !S.habits().some(h => h.id === heatFilter)) heatFilter = 'all';
    $$('.nav a').forEach(a => { const on = a.dataset.view === view; a.classList.toggle('active', on); on ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'); });
    routes[view]();
    $('#streakPill').textContent = `🔥 ${S.overall().current}`;
  }
  function route() {
    const h = location.hash.replace('#/', '');
    view = routes[h] ? h : 'dashboard';
    render(); window.scrollTo(0, 0);
  }

  /* ---------- habit modal ---------- */
  function openHabit(id) {
    editingId = id || null;
    const h = id ? S.habits().find(x => x.id === id) : { name: '', cat: 'Coding', freq: 'everyday', remind: '09:00' };
    const f = form.elements;
    $('#dlgTitle').textContent = id ? 'Edit habit' : 'Add habit';
    f.habitName.value = h.name; f.cat.value = h.cat; f.freq.value = h.freq; f.remind.value = h.remind;
    dlg.showModal(); f.habitName.focus();
  }
  form.addEventListener('submit', e => {
    e.preventDefault();
    const f = form.elements, data = { name: f.habitName.value, cat: f.cat.value, freq: f.freq.value, remind: f.remind.value };
    if (!data.name.trim()) { f.habitName.focus(); toast('Please enter a habit name'); return; }
    if (editingId) { S.updateHabit(editingId, data); toast('Habit updated'); } else { S.addHabit(data); toast('Habit added 🎉'); }
    dlg.close();
  });
  $('#cancelBtn').addEventListener('click', () => dlg.close());

  /* ---------- events (delegated) ---------- */
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-action]'); if (!b) return;
    const { action, id, habit } = b.dataset;
    switch (action) {
      case 'toggle': {
        const was = S.isDone(id), before = S.badges().filter(x => x.earned).length;
        pulseId = id; bump = !was;
        S.toggle(id);                                  // optimistic: re-renders instantly, then persists
        pulseId = null; bump = false;
        $(`.check[data-id="${id}"]`)?.focus({ preventScroll: true });
        if (!was) toast(S.badges().filter(x => x.earned).length > before ? '🏅 New milestone badge unlocked!' : `Checked in! Streak: ${S.overall().current} days 🔥`);
        break;
      }
      case 'add': openHabit(); break;
      case 'edit': openHabit(id); break;
      case 'del': if (confirm('Delete this habit and its history?')) { S.removeHabit(id); toast('Habit deleted'); } break;
      case 'freeze': toast(S.useFreeze() ? '❄️ Streak Freeze used – today is protected' : 'Freeze already used this month'); break;
      case 'nudge': S.nudge(habit); toast(`👋 Nudge sent to ${S.buddyView().name}`); break;
      case 'five': S.highFive(habit); toast('🙌 High-five sent!'); break;
      case 'verify': S.verify(habit); toast('Check-in verified ✔'); break;
      case 'notify': Notification.requestPermission().then(renderSettings); break;
      case 'reset': if (confirm('Replace your data with the demo dataset?')) { S.reset(); toast('Demo data loaded'); } break;
      case 'clear': if (confirm('Delete ALL habits and history?')) { S.clearAll(); toast('All habits cleared'); } break;
      case 'print':
        if (view !== 'analytics') { location.hash = '#/analytics'; setTimeout(() => window.print(), 200); } else window.print();
        break;
    }
  });
  document.addEventListener('change', e => {
    if (e.target.matches('[data-filter]')) { heatFilter = e.target.value; drawHeat($('#heat')); }
  });
  document.addEventListener('submit', e => {
    if (e.target.id !== 'buddyForm') return;
    e.preventDefault();
    const n = e.target.elements.buddy.value.trim().slice(0, 24);
    if (n) { S.setBuddy(n); toast(`Linked with ${n} 🤝`); }
  });
  mq.addEventListener('change', () => drawHeat($('#heat')));
  window.addEventListener('hashchange', route);

  /* ---------- reminders + midnight warning refresh ---------- */
  setInterval(() => {
    const n = new Date(), hm = `${String(n.getHours()).padStart(2, '0')}:${String(n.getMinutes()).padStart(2, '0')}`, t = S.today();
    S.habits().forEach(h => {
      if (h.remind !== hm || S.isDone(h.id) || !S.isDue(h.freq, t)) return;
      const k = `ss.rem.${t}.${h.id}.${hm}`;
      try { if (sessionStorage.getItem(k)) return; sessionStorage.setItem(k, '1'); } catch (err) { /* ignore */ }
      toast(`⏰ Reminder: ${h.name}`);
      if ('Notification' in window && Notification.permission === 'granted') new Notification('StreakSmith', { body: h.name });
    });
  }, 30000);
  setInterval(() => { S.rollover(); if (view === 'dashboard' && !dlg.open) render(); }, 60000);

  /* ---------- boot ---------- */
  S.init();
  S.on(render);
  route();
})();
