# StreakSmith – BuddyBind Hack
Habit tracker + accountability buddy, built with plain HTML, CSS and JavaScript (no installs, no build step).

## Run
Unzip and double-click `index.html` (works offline, data is kept in LocalStorage).

## Files
- `index.html`      – page shell, navigation, add/edit habit dialog (links css/style.css, js/store.js, js/app.js)
- `css/style.css`   – mobile-first CSS Grid layout, heatmap colours, animations, print/PDF styles
- `js/store.js`     – data layer: 6-habit/90-day sample data, LocalStorage, streak algorithm, heatmap levels, freeze, badges, buddy
- `js/app.js`       – UI: router (#/dashboard, #/analytics, #/buddy, #/settings), SVG heatmap, events, reminders
- `standalone.html` – the whole project (HTML + CSS + JS) combined in ONE file; open it on its own, no other files needed
